objs/cpu/wl82/key/rdec.c.o: ../../../../../cpu/wl82/key/rdec.c \
  ../../../../../include_lib/driver/device\key/key_driver.h \
  ../../../../../include_lib/system\generic/typedef.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/cpu.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/WL82.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/csfr.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/irq.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/hwi.h \
  ../../../../../include_lib/system\generic/printf.h \
  ../../../../../include_lib\system/generic/log.h \
  ../../../../../include_lib/system\generic/errno-base.h \
  ../../../../../include_lib/c++/include\string.h \
  ../../../../../include_lib/c++/include\__config \
  ../../../../../include_lib/newlib/include\strings.h \
  ../../../../../include_lib/newlib/include\sys/types.h \
  ../../../../../include_lib/newlib/include\sys/_stdint.h \
  ../../../../../include_lib/c++/include\stddef.h \
  ../../../../../include_lib/newlib/include\machine/types.h \
  ../../../../../include_lib\system/malloc.h \
  ../../../../../include_lib/utils\event/key_event.h \
  ../../../../../include_lib/utils\event/event.h \
  ../../../../../include_lib/driver\device/gpio.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/gpio.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/rdec.h \
  ../../../../../apps/demo/demo_ble/include\app_config.h
