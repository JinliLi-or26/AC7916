objs/apps/common/config/log_config/lib_btstack_config.c.o: \
  ../../../../../apps/common/config/log_config/lib_btstack_config.c \
  ../../../../../apps/demo/demo_ble/include\app_config.h
