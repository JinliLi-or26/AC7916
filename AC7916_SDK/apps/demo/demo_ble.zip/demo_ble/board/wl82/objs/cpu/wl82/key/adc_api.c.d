objs/cpu/wl82/key/adc_api.c.o: ../../../../../cpu/wl82/key/adc_api.c \
  ../../../../../include_lib/system\generic/typedef.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/cpu.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/WL82.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/csfr.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/irq.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/hwi.h \
  ../../../../../include_lib/system\generic/printf.h \
  ../../../../../include_lib\system/generic/log.h \
  ../../../../../include_lib/system\generic/errno-base.h \
  ../../../../../include_lib/c++/include\string.h \
  ../../../../../include_lib/c++/include\__config \
  ../../../../../include_lib/newlib/include\strings.h \
  ../../../../../include_lib/newlib/include\sys/types.h \
  ../../../../../include_lib/newlib/include\sys/_stdint.h \
  ../../../../../include_lib/c++/include\stddef.h \
  ../../../../../include_lib/newlib/include\machine/types.h \
  ../../../../../include_lib\system/malloc.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/clock.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/adc_api.h \
  ../../../../../include_lib\system/timer.h \
  ../../../../../include_lib/system/generic/list.h \
  ../../../../../include_lib\system/spinlock.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/efuse.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/p33.h \
  ../../../../../include_lib/driver/cpu/wl82\asm/power_interface.h
